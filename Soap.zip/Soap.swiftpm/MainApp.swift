import SwiftUI

@main
struct Soap: App {
    var body: some Scene {
        WindowGroup {
            MainGameView()
        }
    }
}
