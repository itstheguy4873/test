import SwiftUI

struct MainGameView: View {
    @State private var games: [Game] = []
    @State private var configSheetIndex: IdentifiableIndex? = nil
    @State private var editorIndex: IdentifiableIndex? = nil
    
    var body: some View {
        NavigationStack {
            ZStack(alignment: .top) {
                Color.white.ignoresSafeArea()
                
                VStack(spacing: 0) {
                    MenuBarView { addGame() }
                    Divider()
                    ScrollView {
                        LazyVStack(spacing: 12) {
                            ForEach($games) { $game in
                                Button {
                                    if let index = games.firstIndex(where: { $0.id == game.id }) {
                                        editorIndex = IdentifiableIndex(id: index)
                                    }
                                } label: {
                                    GameCardView(game: game)
                                }
                                .buttonStyle(.plain)
                            }
                        }
                        .padding()
                    }
                }
            }
            .sheet(item: $configSheetIndex) { item in
                GameDetailSheet(game: $games[item.id])
            }
            .fullScreenCover(item: $editorIndex) { item in
                GameEditorView(game: $games[item.id])
            }
        }
    }
    
    private func addGame() {
        let newGame = Game(id: UUID(), name: "New Game", icon: "gamecontroller.fill", status: .draft)
        games.append(newGame)
        if let index = games.firstIndex(where: { $0.id == newGame.id }) {
            configSheetIndex = IdentifiableIndex(id: index)
        }
    }
}
