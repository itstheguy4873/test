import SwiftUI

struct GameDetailSheet: View {
    @Binding var game: Game
    @Environment(\.dismiss) private var dismiss
    @State private var appear = false
    
    var body: some View {
        ZStack {
            VisualEffectBlur(blurStyle: .systemThinMaterial)
                .ignoresSafeArea()
            
            VStack {
                Spacer()
                
                VStack(spacing: 25) {
                    Image(systemName: "gamecontroller.fill")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 60, height: 60)
                        .foregroundColor(Color.accentColor)
                        .scaleEffect(appear ? 1 : 0.5)
                        .opacity(appear ? 1 : 0)
                        .animation(.spring(response: 0.5, dampingFraction: 0.6), value: appear)
                    
                    Text("Configure Game")
                        .font(.title2)
                        .bold()
                        .opacity(appear ? 1 : 0)
                        .animation(.easeOut.delay(0.1), value: appear)
                    
                    TextField("Game Name", text: $game.name)
                        .padding()
                        .frame(maxWidth: 300)
                        .background(Color(.systemGray6))
                        .cornerRadius(12)
                        .shadow(color: Color.black.opacity(0.05), radius: 5, x: 0, y: 2)
                        .opacity(appear ? 1 : 0)
                        .animation(.easeOut.delay(0.2), value: appear)
                    
                    HStack(spacing: 12) {
                        ForEach(GameStatus.allCases, id: \.self) { status in
                            Button(action: { game.status = status }) {
                                Text(status.title)
                                    .font(.caption)
                                    .fontWeight(.semibold)
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 6)
                                    .background(game.status == status ? Color.accentColor.opacity(0.2) : Color.gray.opacity(0.15))
                                    .foregroundColor(game.status == status ? Color.accentColor : Color.primary)
                                    .clipShape(Capsule())
                            }
                        }
                    }
                    .opacity(appear ? 1 : 0)
                    .animation(.easeOut.delay(0.3), value: appear)
                    
                    StatusBadgeView(status: game.status)
                        .opacity(appear ? 1 : 0)
                        .animation(.easeOut.delay(0.4), value: appear)
                    
                    Button {
                        dismiss()
                    } label: {
                        Text("Save")
                            .bold()
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.accentColor)
                            .foregroundColor(.white)
                            .cornerRadius(12)
                    }
                    .frame(maxWidth: 300)
                }
                
                Spacer()
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .onAppear { appear = true }
        }
        .presentationDetents([.height(400)])
        .presentationDragIndicator(.hidden)
    }
}

struct GameEditorView: View {
    @Binding var game: Game
    @Environment(\.dismiss) private var dismiss
    @State private var selectedTab: String? = "Explorer"
    
    var body: some View {
        HStack(spacing: 0) {
            List {
                Section("Explorer") {
                    Button("Game Info") { selectedTab = "Properties" }
                    Button("Assets") { selectedTab = "Assets" }
                    Button("Settings") { selectedTab = "Settings" }
                }
            }
            .listStyle(SidebarListStyle())
            .frame(minWidth: 200, idealWidth: 220, maxWidth: 250)
            .background(Color(.systemGray6))
            
            Divider()
            
            VStack(spacing: 0) {
                HStack {
                    Text(game.name)
                        .font(.headline)
                    Spacer()
                    Button("Close") { dismiss() }
                }
                .padding()
                .background(Color(.systemGray6))
                
                Divider()
                
                Group {
                    switch selectedTab {
                    case "Properties":
                        PropertiesView(game: $game)
                    case "Assets":
                        AssetsView()
                    case "Settings":
                        SettingsView(game: $game)
                    default:
                        Text("Select an item from Explorer")
                            .foregroundColor(.gray)
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                            .background(Color(.systemBackground))
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color(.systemBackground))
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .ignoresSafeArea()
    }
}

struct PropertiesView: View {
    @Binding var game: Game
    var body: some View {
        Form {
            Section("General") {
                TextField("Name", text: $game.name)
                Picker("Status", selection: $game.status) {
                    ForEach(GameStatus.allCases, id: \.self) { status in
                        Text(status.title).tag(status)
                    }
                }
                .pickerStyle(.segmented)
            }
        }
        .padding()
    }
}

struct AssetsView: View {
    var body: some View {
        VStack {
            Text("Assets").font(.title)
            Text("Add images, sounds, and other resources here.")
                .foregroundColor(.gray)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

struct SettingsView: View {
    @Binding var game: Game
    var body: some View {
        Form {
            Section("Settings") {
                Toggle("Enable Multiplayer", isOn: .constant(true))
                Stepper("Max Players: 4", value: .constant(4), in: 1...10)
            }
        }
        .padding()
    }
}
