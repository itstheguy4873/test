import SwiftUI

struct StatusBadgeView: View {
    let status: GameStatus
    var body: some View {
        Text(status.title)
            .font(.caption2)
            .fontWeight(.semibold)
            .padding(.horizontal, 10)
            .padding(.vertical, 4)
            .background(status.color.opacity(0.15))
            .foregroundColor(status.color)
            .clipShape(Capsule())
    }
}

struct GameCardView: View {
    let game: Game
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: game.icon)
                .resizable()
                .scaledToFit()
                .frame(width: 48, height: 48)
                .padding(8)
                .background(
                    RoundedRectangle(cornerRadius: 8)
                        .fill(Color.gray.opacity(0.1))
                        .shadow(color: .black.opacity(0.05), radius: 2, x: 0, y: 1)
                )
            
            VStack(alignment: .leading, spacing: 4) {
                Text(game.name)
                    .font(.headline)
                    .foregroundColor(.primary)
                
                StatusBadgeView(status: game.status)
            }
            
            Spacer()
            
            Image(systemName: "chevron.right")
                .foregroundColor(.gray)
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(Color(.systemBackground))
                .shadow(color: Color.black.opacity(0.08), radius: 6, x: 0, y: 4)
        )
    }
}

struct MenuBarView: View {
    let onNew: () -> Void
    var body: some View {
        HStack(spacing: 24) {
            Menu("File") { Button("New Game", action: onNew) }
            Menu("Edit") { Button("Delete") {} }
            Menu("View") { Button("Refresh") {} }
            Spacer()
        }
        .padding(.horizontal)
        .frame(height: 44)
        .background(.ultraThinMaterial)
    }
}

struct VisualEffectBlur: UIViewRepresentable {
    var blurStyle: UIBlurEffect.Style
    func makeUIView(context: Context) -> UIVisualEffectView {
        UIVisualEffectView(effect: UIBlurEffect(style: blurStyle))
    }
    func updateUIView(_ uiView: UIVisualEffectView, context: Context) {}
}
