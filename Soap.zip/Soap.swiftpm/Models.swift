import SwiftUI

enum GameStatus: String, CaseIterable {
    case draft, inProgress, completed
    
    var title: String {
        switch self {
        case .draft: return "Draft"
        case .inProgress: return "In Progress"
        case .completed: return "Completed"
        }
    }
    
    var color: Color {
        switch self {
        case .draft: return .gray
        case .inProgress: return .orange
        case .completed: return .green
        }
    }
}

struct Game: Identifiable, Equatable {
    let id: UUID
    var name: String
    var icon: String
    var status: GameStatus
}

struct IdentifiableIndex: Identifiable {
    let id: Int
}
